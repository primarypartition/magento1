CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `core_config_data`
--

DROP TABLE IF EXISTS `core_config_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_config_data` (
  `config_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Config ID',
  `scope` varchar(8) NOT NULL DEFAULT 'default' COMMENT 'Config Scope',
  `scope_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Config Scope ID',
  `path` varchar(255) NOT NULL DEFAULT 'general' COMMENT 'Config Path',
  `value` text DEFAULT NULL COMMENT 'Config Value',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Updated At',
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `CORE_CONFIG_DATA_SCOPE_SCOPE_ID_PATH` (`scope`,`scope_id`,`path`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COMMENT='Config Data';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_config_data`
--

LOCK TABLES `core_config_data` WRITE;
/*!40000 ALTER TABLE `core_config_data` DISABLE KEYS */;
INSERT INTO `core_config_data` VALUES (1,'default',0,'yotpo/module_info/yotpo_installation_date','2020-09-18','2020-09-18 22:06:40'),(2,'default',0,'yotpo/sync_settings/orders_sync_start_date','2020-09-18','2020-09-18 22:06:40'),(3,'default',0,'web/seo/use_rewrites','1','2020-09-18 22:06:58'),(4,'default',0,'web/unsecure/base_url','http://local.magento.pro2/','2020-09-18 22:06:59'),(5,'default',0,'general/locale/code','en_US','2020-09-18 22:06:59'),(6,'default',0,'general/locale/timezone','America/Denver','2020-09-18 22:06:59'),(7,'default',0,'currency/options/base','USD','2020-09-18 22:07:00'),(8,'default',0,'currency/options/default','USD','2020-09-18 22:07:00'),(9,'default',0,'currency/options/allow','EUR,USD','2020-09-21 22:17:31'),(10,'default',0,'general/region/display_all','1','2020-09-18 22:07:04'),(11,'default',0,'general/region/state_required','AU,BR,CA,CH,CN,CO,EE,ES,HR,IN,IT,LT,LV,MX,PL,RO,US','2020-09-18 22:07:08'),(12,'default',0,'catalog/category/root_id','2','2020-09-18 22:07:44'),(13,'default',0,'analytics/subscription/enabled','1','2020-09-18 22:08:11'),(14,'default',0,'crontab/default/jobs/analytics_subscribe/schedule/cron_expr','0 * * * *','2020-09-18 22:08:11'),(15,'default',0,'crontab/default/jobs/analytics_collect_data/schedule/cron_expr','00 02 * * *','2020-09-18 22:08:13'),(16,'default',0,'msp_securitysuite_recaptcha/frontend/enabled','0','2020-09-18 22:08:17'),(17,'default',0,'msp_securitysuite_recaptcha/backend/enabled','0','2020-09-18 22:08:17'),(18,'default',0,'twofactorauth/duo/application_key','zQAgAbNrkIwzzjo9I8nAovJRYqnlR9PFEeljq2KQZFcoQgawXCEfjFbropEDPKaj','2020-09-18 22:08:22'),(19,'website',0,'connector_configuration/transactional_data/order_statuses','canceled,closed,complete,fraud,holded,payment_review,paypal_canceled_reversal,paypal_reversed,pending,pending_payment,pending_paypal,processing','2020-09-18 22:08:26'),(20,'website',0,'connector_configuration/catalog_sync/catalog_type','simple,virtual,downloadable,configurable,grouped,bundle','2020-09-18 22:08:26'),(21,'website',0,'connector_configuration/catalog_sync/catalog_visibility','1,2,3,4','2020-09-18 22:08:26'),(22,'default',0,'connector_dynamic_content/external_dynamic_content_urls/passcode','qa4KAfWaFRhHEeioM3enWv6I8KL2VL5H','2020-09-18 22:08:26'),(23,'default',0,'connector_automation/review_settings/allow_non_subscribers','1','2020-09-18 22:08:26'),(24,'default',0,'connector_configuration/abandoned_carts/allow_non_subscribers','1','2020-09-18 22:08:27'),(25,'default',0,'sync_settings/addressbook/allow_non_subscribers','1','2020-09-18 22:08:27'),(26,'default',0,'admin/usage/enabled','0','2020-09-18 22:41:57'),(27,'default',0,'carriers/tablerate/active','1','2020-09-19 02:37:58'),(28,'default',0,'carriers/tablerate/condition_name','package_value_with_discount','2020-09-19 02:37:58'),(29,'default',0,'sales/msrp/enabled','1','2020-09-19 02:38:04'),(30,'default',0,'design/theme/theme_id','3','2020-09-19 02:40:56'),(31,'default',0,'design/head/includes','<link  rel=\"stylesheet\" type=\"text/css\"  media=\"all\" href=\"{{MEDIA_URL}}styles.css\" />','2020-09-19 02:40:56'),(32,'default',0,'currency/fixerio/api_key',NULL,'2020-09-21 22:17:31'),(33,'default',0,'currency/fixerio/timeout','100','2020-09-21 22:17:31'),(34,'default',0,'currency/currencyconverterapi/api_key',NULL,'2020-09-21 22:17:31'),(35,'default',0,'currency/currencyconverterapi/timeout','100','2020-09-21 22:17:31'),(36,'default',0,'admin/security/use_form_key','0','2020-09-22 17:22:53'),(37,'default',0,'mastering/general/enabled','0','2020-09-23 16:40:00'),(39,'default',0,'dev/front_end_development_workflow/type','server_side_compilation','2020-09-24 22:53:15'),(40,'default',0,'dev/restrict/allow_ips',NULL,'2020-09-24 22:47:03'),(41,'default',0,'dev/debug/template_hints_storefront','0','2020-09-25 01:54:33'),(42,'default',0,'dev/debug/template_hints_admin','0','2020-09-24 22:47:03'),(43,'default',0,'dev/debug/template_hints_blocks','0','2020-09-24 22:47:03'),(44,'default',0,'dev/template/allow_symlink','0','2020-09-24 22:47:03'),(45,'default',0,'dev/translate_inline/active','0','2020-09-24 22:47:03'),(46,'default',0,'dev/translate_inline/active_admin','0','2020-09-24 22:47:03'),(47,'default',0,'dev/debug/template_hints_storefront_show_with_parameter','0','2020-09-25 01:15:19');
/*!40000 ALTER TABLE `core_config_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:37:12
