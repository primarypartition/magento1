CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `catalog_category_entity_varchar`
--

DROP TABLE IF EXISTS `catalog_category_entity_varchar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_varchar` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Entity ID',
  `value` varchar(255) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `CATALOG_CATEGORY_ENTITY_VARCHAR_ENTITY_ID_ATTRIBUTE_ID_STORE_ID` (`entity_id`,`attribute_id`,`store_id`),
  KEY `CATALOG_CATEGORY_ENTITY_VARCHAR_ENTITY_ID` (`entity_id`),
  KEY `CATALOG_CATEGORY_ENTITY_VARCHAR_ATTRIBUTE_ID` (`attribute_id`),
  KEY `CATALOG_CATEGORY_ENTITY_VARCHAR_STORE_ID` (`store_id`),
  CONSTRAINT `CATALOG_CATEGORY_ENTITY_VARCHAR_STORE_ID_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`) ON DELETE CASCADE,
  CONSTRAINT `CAT_CTGR_ENTT_VCHR_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  CONSTRAINT `CAT_CTGR_ENTT_VCHR_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Varchar Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_varchar`
--

LOCK TABLES `catalog_category_entity_varchar` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_varchar` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_varchar` VALUES (1,45,0,1,'Root Catalog'),(2,45,0,2,'Default Category'),(3,52,0,2,'PRODUCTS'),(4,45,0,3,'Gear'),(5,52,0,3,'PAGE'),(6,119,0,3,'gear'),(7,120,0,3,'gear'),(8,45,0,4,'Bags'),(9,119,0,4,'bags'),(10,120,0,4,'gear/bags'),(11,45,0,5,'Fitness Equipment'),(12,119,0,5,'fitness-equipment'),(13,120,0,5,'gear/fitness-equipment'),(14,45,0,6,'Watches'),(15,119,0,6,'watches'),(16,120,0,6,'gear/watches'),(17,45,0,7,'Collections'),(18,52,0,7,'PAGE'),(19,119,0,7,'collections'),(20,120,0,7,'collections'),(21,45,0,8,'New Luma Yoga Collection'),(22,119,0,8,'yoga-new'),(23,120,0,8,'collections/yoga-new'),(24,45,0,9,'Training'),(25,52,0,9,'PAGE'),(26,119,0,9,'training'),(27,120,0,9,'training'),(28,45,0,10,'Video Download'),(29,119,0,10,'training-video'),(30,120,0,10,'training/training-video'),(31,45,0,11,'Men'),(32,52,0,11,'PAGE'),(33,119,0,11,'men'),(34,120,0,11,'men'),(35,45,0,12,'Tops'),(36,119,0,12,'tops-men'),(37,120,0,12,'men/tops-men'),(38,45,0,13,'Bottoms'),(39,119,0,13,'bottoms-men'),(40,120,0,13,'men/bottoms-men'),(41,45,0,14,'Jackets'),(42,119,0,14,'jackets-men'),(43,120,0,14,'men/tops-men/jackets-men'),(44,45,0,15,'Hoodies & Sweatshirts'),(45,119,0,15,'hoodies-and-sweatshirts-men'),(46,120,0,15,'men/tops-men/hoodies-and-sweatshirts-men'),(47,45,0,16,'Tees'),(48,119,0,16,'tees-men'),(49,120,0,16,'men/tops-men/tees-men'),(50,45,0,17,'Tanks'),(51,119,0,17,'tanks-men'),(52,120,0,17,'men/tops-men/tanks-men'),(53,45,0,18,'Pants'),(54,119,0,18,'pants-men'),(55,120,0,18,'men/bottoms-men/pants-men'),(56,45,0,19,'Shorts'),(57,119,0,19,'shorts-men'),(58,120,0,19,'men/bottoms-men/shorts-men'),(59,45,0,20,'Women'),(60,52,0,20,'PAGE'),(61,119,0,20,'women'),(62,120,0,20,'women'),(63,45,0,21,'Tops'),(64,119,0,21,'tops-women'),(65,120,0,21,'women/tops-women'),(66,45,0,22,'Bottoms'),(67,119,0,22,'bottoms-women'),(68,120,0,22,'women/bottoms-women'),(69,45,0,23,'Jackets'),(70,119,0,23,'jackets-women'),(71,120,0,23,'women/tops-women/jackets-women'),(72,45,0,24,'Hoodies & Sweatshirts'),(73,119,0,24,'hoodies-and-sweatshirts-women'),(74,120,0,24,'women/tops-women/hoodies-and-sweatshirts-women'),(75,45,0,25,'Tees'),(76,119,0,25,'tees-women'),(77,120,0,25,'women/tops-women/tees-women'),(78,45,0,26,'Bras & Tanks'),(79,119,0,26,'tanks-women'),(80,120,0,26,'women/tops-women/tanks-women'),(81,45,0,27,'Pants'),(82,119,0,27,'pants-women'),(83,120,0,27,'women/bottoms-women/pants-women'),(84,45,0,28,'Shorts'),(85,119,0,28,'shorts-women'),(86,120,0,28,'women/bottoms-women/shorts-women'),(87,45,0,29,'Promotions'),(88,52,0,29,'PAGE'),(89,119,0,29,'promotions'),(90,120,0,29,'promotions'),(91,45,0,30,'Women Sale'),(92,119,0,30,'women-sale'),(93,120,0,30,'promotions/women-sale'),(94,45,0,31,'Men Sale'),(95,119,0,31,'men-sale'),(96,120,0,31,'promotions/men-sale'),(97,45,0,32,'Pants'),(98,119,0,32,'pants-all'),(99,120,0,32,'promotions/pants-all'),(100,45,0,33,'Tees'),(101,119,0,33,'tees-all'),(102,120,0,33,'promotions/tees-all'),(103,45,0,34,'Erin Recommends'),(104,119,0,34,'erin-recommends'),(105,120,0,34,'collections/erin-recommends'),(106,45,0,35,'Performance Fabrics'),(107,119,0,35,'performance-fabrics'),(108,120,0,35,'collections/performance-fabrics'),(109,45,0,36,'Eco Friendly'),(110,119,0,36,'eco-friendly'),(111,120,0,36,'collections/eco-friendly'),(112,45,0,37,'Sale'),(113,52,0,37,'PAGE'),(114,119,0,37,'sale'),(115,120,0,37,'sale'),(116,45,0,38,'What\'s New'),(117,52,0,38,'PAGE'),(118,119,0,38,'what-is-new'),(119,120,0,38,'what-is-new'),(120,45,0,39,'Performance Sportswear New'),(121,52,0,39,'PAGE'),(122,63,0,39,'1column'),(123,119,0,39,'performance-new'),(124,120,0,39,'collections/performance-new'),(125,45,0,40,'Eco Collection New'),(126,52,0,40,'PAGE'),(127,63,0,40,'1column'),(128,119,0,40,'eco-new'),(129,120,0,40,'collections/eco-new');
/*!40000 ALTER TABLE `catalog_category_entity_varchar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:36:11
