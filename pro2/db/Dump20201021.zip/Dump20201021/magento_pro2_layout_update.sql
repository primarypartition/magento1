CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `layout_update`
--

DROP TABLE IF EXISTS `layout_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layout_update` (
  `layout_update_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Layout Update ID',
  `handle` varchar(255) DEFAULT NULL COMMENT 'Handle',
  `xml` text DEFAULT NULL COMMENT 'Xml',
  `sort_order` smallint(6) NOT NULL DEFAULT 0 COMMENT 'Sort Order',
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp() COMMENT 'Last Update Timestamp',
  PRIMARY KEY (`layout_update_id`),
  KEY `LAYOUT_UPDATE_HANDLE` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='Layout Updates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_update`
--

LOCK TABLES `layout_update` WRITE;
/*!40000 ALTER TABLE `layout_update` DISABLE KEYS */;
INSERT INTO `layout_update` VALUES (1,'contact_index_index','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"2BDKvT6B4PfIDykkP4NdXusVBtyY8O2X\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">2</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(2,'default','<body><referenceContainer name=\"cms_footer_links_container\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"SM35kgc7UMNaQbbjrM8ZkBPMQxYL3Rj9\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">1</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(3,'catalog_category_view_id_37','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"lMbKYXLVapCs2mc26vY1aRFWby4iZTk3\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">3</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(4,'catalog_category_view_id_3','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"ee1jWLlgudZ1qkH94pxfhbSYaYzF4bot\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">4</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(5,'catalog_category_view_id_11','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"WGhGB3c2W0P8IoRRVaJMDZqrdZTMCu54\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">5</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(6,'catalog_category_view_id_20','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"XZ9ofmRMj0fj5tC2rVd0AR1zsuBfipR9\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">6</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(7,'catalog_category_view_id_38','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"N9Ui6eBytWq43O2Adag7qDK0nhNjwfOV\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">7</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(8,'catalog_category_view_id_20','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"CsiQblZBe4VybMPSZYfxFOUIOvIvCUPD\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">8</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(9,'catalog_category_view_id_9','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"YWVB02sI5AUlZSQnhb5Yx8riWzW3kCPu\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">9</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(10,'catalog_category_view_id_11','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"VORLUBCVgB5r2wdFuPuaal3Me2HtYiqc\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">10</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(11,'catalog_category_view_id_3','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"Xj3uDsuucGByqCRdsUOD2bTLhDhCR7TT\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">11</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(12,'catalog_category_view_id_38','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"K5o1KVwot8JkLjrcLWHjVpKq9xBvqZfE\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">13</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(13,'catalog_category_view_id_37','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"sBY7ZOi1SyxJNFtqywYoN9RxIQnIhmYP\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">12</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(14,'cms_index_index','<body><referenceContainer name=\"content\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"L4hIJIwysCUOC4uzuiFjPhuKvjgUjxHM\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">14</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(15,'catalog_category_view_id_39','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"cdRhfm3LG7WG7B4OLFJOHXrvBGEq24XQ\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">15</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(16,'catalog_category_view_id_40','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"UP26yFlfBAZABnJCESYZ9l0L4iTb8Mvy\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">16</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(17,'customer_account_login','<body><referenceContainer name=\"customer.login.container\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"Gbv9XfNhrOwIR1WAwhZxKssk4ZAK7xbZ\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">18</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(18,'catalog_category_view_id_','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"K8vVjwHIE2n8rzPgNBKeqWFwz3VmKz67\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">17</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `layout_update` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:36:47
