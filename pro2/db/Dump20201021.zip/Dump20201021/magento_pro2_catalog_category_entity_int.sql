CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `catalog_category_entity_int`
--

DROP TABLE IF EXISTS `catalog_category_entity_int`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_int` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Entity ID',
  `value` int(11) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `CATALOG_CATEGORY_ENTITY_INT_ENTITY_ID_ATTRIBUTE_ID_STORE_ID` (`entity_id`,`attribute_id`,`store_id`),
  KEY `CATALOG_CATEGORY_ENTITY_INT_ENTITY_ID` (`entity_id`),
  KEY `CATALOG_CATEGORY_ENTITY_INT_ATTRIBUTE_ID` (`attribute_id`),
  KEY `CATALOG_CATEGORY_ENTITY_INT_STORE_ID` (`store_id`),
  CONSTRAINT `CATALOG_CATEGORY_ENTITY_INT_STORE_ID_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`) ON DELETE CASCADE,
  CONSTRAINT `CAT_CTGR_ENTT_INT_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  CONSTRAINT `CAT_CTGR_ENTT_INT_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Integer Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_int`
--

LOCK TABLES `catalog_category_entity_int` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_int` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_int` VALUES (1,69,0,1,1),(2,46,0,2,1),(3,69,0,2,1),(4,46,0,3,1),(5,54,0,3,0),(6,69,0,3,1),(7,46,0,4,1),(8,54,0,4,1),(9,69,0,4,1),(10,46,0,5,1),(11,54,0,5,1),(12,69,0,5,1),(13,46,0,6,1),(14,54,0,6,1),(15,69,0,6,1),(16,46,0,7,0),(17,54,0,7,0),(18,69,0,7,0),(19,46,0,8,1),(20,54,0,8,1),(21,69,0,8,0),(22,46,0,9,1),(23,54,0,9,0),(24,69,0,9,1),(25,46,0,10,1),(26,54,0,10,1),(27,69,0,10,1),(28,46,0,11,1),(29,54,0,11,0),(30,69,0,11,1),(31,46,0,12,1),(32,54,0,12,1),(33,69,0,12,1),(34,46,0,13,1),(35,54,0,13,1),(36,69,0,13,1),(37,46,0,14,1),(38,54,0,14,1),(39,69,0,14,1),(40,46,0,15,1),(41,54,0,15,1),(42,69,0,15,1),(43,46,0,16,1),(44,54,0,16,1),(45,69,0,16,1),(46,46,0,17,1),(47,54,0,17,1),(48,69,0,17,1),(49,46,0,18,1),(50,54,0,18,1),(51,69,0,18,1),(52,46,0,19,1),(53,54,0,19,1),(54,69,0,19,1),(55,46,0,20,1),(56,54,0,20,0),(57,69,0,20,1),(58,46,0,21,1),(59,54,0,21,1),(60,69,0,21,1),(61,46,0,22,1),(62,54,0,22,1),(63,69,0,22,1),(64,46,0,23,1),(65,54,0,23,1),(66,69,0,23,1),(67,46,0,24,1),(68,54,0,24,1),(69,69,0,24,1),(70,46,0,25,1),(71,54,0,25,1),(72,69,0,25,1),(73,46,0,26,1),(74,54,0,26,1),(75,69,0,26,1),(76,46,0,27,1),(77,54,0,27,1),(78,69,0,27,1),(79,46,0,28,1),(80,54,0,28,1),(81,69,0,28,1),(82,46,0,29,0),(83,54,0,29,0),(84,69,0,29,0),(85,46,0,30,1),(86,54,0,30,1),(87,69,0,30,0),(88,46,0,31,1),(89,54,0,31,1),(90,69,0,31,0),(91,46,0,32,1),(92,54,0,32,1),(93,69,0,32,0),(94,46,0,33,1),(95,54,0,33,1),(96,69,0,33,0),(97,46,0,34,1),(98,54,0,34,1),(99,69,0,34,0),(100,46,0,35,1),(101,54,0,35,1),(102,69,0,35,0),(103,46,0,36,1),(104,54,0,36,1),(105,69,0,36,0),(106,46,0,37,1),(107,54,0,37,0),(108,69,0,37,1),(109,46,0,38,1),(110,54,0,38,0),(111,69,0,38,1),(112,46,0,39,1),(113,54,0,39,0),(114,69,0,39,0),(115,46,0,40,1),(116,54,0,40,0),(117,69,0,40,0);
/*!40000 ALTER TABLE `catalog_category_entity_int` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:36:14
