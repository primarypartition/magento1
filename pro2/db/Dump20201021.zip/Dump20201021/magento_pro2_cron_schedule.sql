CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cron_schedule`
--

DROP TABLE IF EXISTS `cron_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cron_schedule` (
  `schedule_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Schedule ID',
  `job_code` varchar(255) NOT NULL DEFAULT '0' COMMENT 'Job Code',
  `status` varchar(7) NOT NULL DEFAULT 'pending' COMMENT 'Status',
  `messages` text DEFAULT NULL COMMENT 'Messages',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Created At',
  `scheduled_at` timestamp NULL DEFAULT NULL COMMENT 'Scheduled At',
  `executed_at` timestamp NULL DEFAULT NULL COMMENT 'Executed At',
  `finished_at` timestamp NULL DEFAULT NULL COMMENT 'Finished At',
  PRIMARY KEY (`schedule_id`),
  KEY `CRON_SCHEDULE_JOB_CODE` (`job_code`),
  KEY `CRON_SCHEDULE_SCHEDULED_AT_STATUS` (`scheduled_at`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='Cron Schedule';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_schedule`
--

LOCK TABLES `cron_schedule` WRITE;
/*!40000 ALTER TABLE `cron_schedule` DISABLE KEYS */;
INSERT INTO `cron_schedule` VALUES (1,'consumers_runner','error','The job is terminated due to system upgrade','2020-09-23 02:00:09','2020-09-23 02:00:00','2020-09-23 02:00:26',NULL),(2,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:01:00',NULL,NULL),(3,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:02:00',NULL,NULL),(4,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:03:00',NULL,NULL),(5,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:04:00',NULL,NULL),(6,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:05:00',NULL,NULL),(7,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:06:00',NULL,NULL),(8,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:07:00',NULL,NULL),(9,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:08:00',NULL,NULL),(10,'consumers_runner','pending',NULL,'2020-09-23 02:00:09','2020-09-23 02:09:00',NULL,NULL),(11,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:10:00',NULL,NULL),(12,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:11:00',NULL,NULL),(13,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:12:00',NULL,NULL),(14,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:13:00',NULL,NULL),(15,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:14:00',NULL,NULL),(16,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:15:00',NULL,NULL),(17,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:16:00',NULL,NULL),(18,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:17:00',NULL,NULL),(19,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:18:00',NULL,NULL),(20,'consumers_runner','pending',NULL,'2020-09-23 02:00:10','2020-09-23 02:19:00',NULL,NULL);
/*!40000 ALTER TABLE `cron_schedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:36:33
