CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `catalog_product_super_attribute_label`
--

DROP TABLE IF EXISTS `catalog_product_super_attribute_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_product_super_attribute_label` (
  `value_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `product_super_attribute_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Product Super Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Store ID',
  `use_default` smallint(5) unsigned DEFAULT 0 COMMENT 'Use Default Value',
  `value` varchar(255) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `CAT_PRD_SPR_ATTR_LBL_PRD_SPR_ATTR_ID_STORE_ID` (`product_super_attribute_id`,`store_id`),
  KEY `CATALOG_PRODUCT_SUPER_ATTRIBUTE_LABEL_STORE_ID` (`store_id`),
  CONSTRAINT `CATALOG_PRODUCT_SUPER_ATTRIBUTE_LABEL_STORE_ID_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_309442281DF7784210ED82B2CC51E5D5` FOREIGN KEY (`product_super_attribute_id`) REFERENCES `catalog_product_super_attribute` (`product_super_attribute_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8 COMMENT='Catalog Product Super Attribute Label Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_product_super_attribute_label`
--

LOCK TABLES `catalog_product_super_attribute_label` WRITE;
/*!40000 ALTER TABLE `catalog_product_super_attribute_label` DISABLE KEYS */;
INSERT INTO `catalog_product_super_attribute_label` VALUES (1,2,0,0,'Size'),(2,3,0,0,'Color'),(3,4,0,0,'Size'),(4,5,0,0,'Color'),(5,6,0,0,'Size'),(6,7,0,0,'Color'),(7,8,0,0,'Size'),(8,9,0,0,'Color'),(9,10,0,0,'Size'),(10,11,0,0,'Color'),(11,12,0,0,'Size'),(12,13,0,0,'Color'),(13,14,0,0,'Size'),(14,15,0,0,'Color'),(15,16,0,0,'Size'),(16,17,0,0,'Color'),(17,18,0,0,'Size'),(18,19,0,0,'Color'),(19,20,0,0,'Size'),(20,21,0,0,'Color'),(21,22,0,0,'Size'),(22,23,0,0,'Color'),(23,24,0,0,'Size'),(24,25,0,0,'Color'),(25,26,0,0,'Size'),(26,27,0,0,'Color'),(27,28,0,0,'Size'),(28,29,0,0,'Color'),(29,30,0,0,'Size'),(30,31,0,0,'Color'),(31,32,0,0,'Size'),(32,33,0,0,'Color'),(33,34,0,0,'Size'),(34,35,0,0,'Color'),(35,36,0,0,'Size'),(36,37,0,0,'Color'),(37,38,0,0,'Size'),(38,39,0,0,'Color'),(39,40,0,0,'Size'),(40,41,0,0,'Color'),(41,42,0,0,'Size'),(42,43,0,0,'Color'),(43,44,0,0,'Size'),(44,45,0,0,'Color'),(45,46,0,0,'Size'),(46,47,0,0,'Color'),(47,48,0,0,'Size'),(48,49,0,0,'Color'),(49,50,0,0,'Size'),(50,51,0,0,'Color'),(51,52,0,0,'Size'),(52,53,0,0,'Color'),(53,54,0,0,'Size'),(54,55,0,0,'Color'),(55,56,0,0,'Size'),(56,57,0,0,'Color'),(57,58,0,0,'Size'),(58,59,0,0,'Color'),(59,60,0,0,'Size'),(60,61,0,0,'Color'),(61,62,0,0,'Size'),(62,63,0,0,'Color'),(63,64,0,0,'Size'),(64,65,0,0,'Color'),(65,66,0,0,'Size'),(66,67,0,0,'Color'),(67,68,0,0,'Size'),(68,69,0,0,'Color'),(69,70,0,0,'Size'),(70,71,0,0,'Color'),(71,72,0,0,'Size'),(72,73,0,0,'Color'),(73,74,0,0,'Size'),(74,75,0,0,'Color'),(75,76,0,0,'Size'),(76,77,0,0,'Color'),(77,78,0,0,'Size'),(78,79,0,0,'Color'),(79,80,0,0,'Size'),(80,81,0,0,'Color'),(81,82,0,0,'Size'),(82,83,0,0,'Color'),(83,84,0,0,'Size'),(84,85,0,0,'Color'),(85,86,0,0,'Size'),(86,87,0,0,'Color'),(87,88,0,0,'Size'),(88,89,0,0,'Color'),(89,90,0,0,'Size'),(90,91,0,0,'Color'),(91,92,0,0,'Size'),(92,93,0,0,'Color'),(93,94,0,0,'Size'),(94,95,0,0,'Color'),(95,96,0,0,'Size'),(96,97,0,0,'Color'),(97,98,0,0,'Size'),(98,99,0,0,'Color'),(99,100,0,0,'Size'),(100,101,0,0,'Color'),(101,102,0,0,'Size'),(102,103,0,0,'Color'),(103,104,0,0,'Size'),(104,105,0,0,'Color'),(105,106,0,0,'Size'),(106,107,0,0,'Color'),(107,108,0,0,'Size'),(108,109,0,0,'Color'),(109,110,0,0,'Size'),(110,111,0,0,'Color'),(111,112,0,0,'Size'),(112,113,0,0,'Color'),(113,114,0,0,'Size'),(114,115,0,0,'Color'),(115,116,0,0,'Size'),(116,117,0,0,'Color'),(117,118,0,0,'Size'),(118,119,0,0,'Color'),(119,120,0,0,'Size'),(120,121,0,0,'Color'),(121,122,0,0,'Size'),(122,123,0,0,'Color'),(123,124,0,0,'Size'),(124,125,0,0,'Color'),(125,126,0,0,'Size'),(126,127,0,0,'Color'),(127,128,0,0,'Size'),(128,129,0,0,'Color'),(129,130,0,0,'Size'),(130,131,0,0,'Color'),(131,132,0,0,'Size'),(132,133,0,0,'Color'),(133,134,0,0,'Size'),(134,135,0,0,'Color'),(135,136,0,0,'Size'),(136,137,0,0,'Color'),(137,138,0,0,'Size'),(138,139,0,0,'Color'),(139,140,0,0,'Size'),(140,141,0,0,'Color'),(141,142,0,0,'Size'),(142,143,0,0,'Color'),(143,144,0,0,'Size'),(144,145,0,0,'Color'),(145,146,0,0,'Size'),(146,147,0,0,'Color'),(147,148,0,0,'Size'),(148,149,0,0,'Color'),(149,150,0,0,'Size'),(150,151,0,0,'Color'),(151,152,0,0,'Size'),(152,153,0,0,'Color'),(153,154,0,0,'Size'),(154,155,0,0,'Color'),(155,156,0,0,'Size'),(156,157,0,0,'Color'),(157,158,0,0,'Size'),(158,159,0,0,'Color'),(159,160,0,0,'Size'),(160,161,0,0,'Color'),(161,162,0,0,'Size'),(162,163,0,0,'Color'),(163,164,0,0,'Size'),(164,165,0,0,'Color'),(165,166,0,0,'Size'),(166,167,0,0,'Color'),(167,168,0,0,'Size'),(168,169,0,0,'Color'),(169,170,0,0,'Size'),(170,171,0,0,'Color'),(171,172,0,0,'Size'),(172,173,0,0,'Color'),(173,174,0,0,'Size'),(174,175,0,0,'Color'),(175,176,0,0,'Size'),(176,177,0,0,'Color'),(177,178,0,0,'Size'),(178,179,0,0,'Color'),(179,180,0,0,'Size'),(180,181,0,0,'Color'),(181,182,0,0,'Size'),(182,183,0,0,'Color'),(183,184,0,0,'Size'),(184,185,0,0,'Color'),(185,186,0,0,'Size'),(186,187,0,0,'Color'),(187,188,0,0,'Size'),(188,189,0,0,'Color'),(189,190,0,0,'Size'),(190,191,0,0,'Color'),(191,192,0,0,'Size'),(192,193,0,0,'Color'),(193,194,0,0,'Size'),(194,195,0,0,'Color'),(195,196,0,0,'Size'),(196,197,0,0,'Color'),(197,198,0,0,'Size'),(198,199,0,0,'Color'),(199,200,0,0,'Size'),(200,201,0,0,'Color'),(201,202,0,0,'Size'),(202,203,0,0,'Color'),(203,204,0,0,'Size'),(204,205,0,0,'Color'),(205,206,0,0,'Size'),(206,207,0,0,'Color'),(207,208,0,0,'Size'),(208,209,0,0,'Color'),(209,210,0,0,'Size'),(210,211,0,0,'Color'),(211,212,0,0,'Size'),(212,213,0,0,'Color'),(213,214,0,0,'Size'),(214,215,0,0,'Color'),(215,216,0,0,'Size'),(216,217,0,0,'Color'),(217,218,0,0,'Size'),(218,219,0,0,'Color'),(219,220,0,0,'Size'),(220,221,0,0,'Color'),(221,222,0,0,'Size'),(222,223,0,0,'Color'),(223,224,0,0,'Size'),(224,225,0,0,'Color'),(225,226,0,0,'Size'),(226,227,0,0,'Color'),(227,228,0,0,'Size'),(228,229,0,0,'Color'),(229,230,0,0,'Size'),(230,231,0,0,'Color'),(231,232,0,0,'Size'),(232,233,0,0,'Color'),(233,234,0,0,'Size'),(234,235,0,0,'Color'),(235,236,0,0,'Size'),(236,237,0,0,'Color'),(237,238,0,0,'Size'),(238,239,0,0,'Color'),(239,240,0,0,'Size'),(240,241,0,0,'Color'),(241,242,0,0,'Size'),(242,243,0,0,'Color'),(243,244,0,0,'Size'),(244,245,0,0,'Color'),(245,246,0,0,'Size'),(246,247,0,0,'Color'),(247,248,0,0,'Size'),(248,249,0,0,'Color'),(249,250,0,0,'Size'),(250,251,0,0,'Color'),(251,252,0,0,'Size'),(252,253,0,0,'Color'),(253,254,0,0,'Size'),(254,255,0,0,'Color'),(255,256,0,0,'Size'),(256,257,0,0,'Color'),(257,258,0,0,'Size'),(258,259,0,0,'Color'),(259,260,0,0,'Size'),(260,261,0,0,'Color'),(261,262,0,0,'Size'),(262,263,0,0,'Color'),(263,264,0,0,'Size'),(264,265,0,0,'Color'),(265,266,0,0,'Size'),(266,267,0,0,'Color'),(267,268,0,0,'Size'),(268,269,0,0,'Color'),(269,270,0,0,'Size'),(270,271,0,0,'Color'),(271,272,0,0,'Size'),(272,273,0,0,'Color'),(273,274,0,0,'Size'),(274,275,0,0,'Color'),(275,276,0,0,'Size'),(276,277,0,0,'Color'),(277,278,0,0,'Size'),(278,279,0,0,'Color'),(279,280,0,0,'Size'),(280,281,0,0,'Color'),(281,282,0,0,'Size'),(282,283,0,0,'Color'),(283,284,0,0,'Size'),(284,285,0,0,'Color'),(285,286,0,0,'Size'),(286,287,0,0,'Color'),(287,288,0,0,'Size'),(288,289,0,0,'Color'),(289,290,0,0,'Size'),(290,291,0,0,'Color'),(291,292,0,0,'Size'),(292,293,0,0,'Color'),(293,294,0,0,'Size'),(294,295,0,0,'Color');
/*!40000 ALTER TABLE `catalog_product_super_attribute_label` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:36:50
