CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `widget_instance_page`
--

DROP TABLE IF EXISTS `widget_instance_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_instance_page` (
  `page_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Page ID',
  `instance_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Instance ID',
  `page_group` varchar(25) DEFAULT NULL COMMENT 'Block Group Type',
  `layout_handle` varchar(255) DEFAULT NULL COMMENT 'Layout Handle',
  `block_reference` varchar(255) DEFAULT NULL COMMENT 'Container',
  `page_for` varchar(25) DEFAULT NULL COMMENT 'For instance entities',
  `entities` text DEFAULT NULL COMMENT 'Catalog entities (comma separated)',
  `page_template` varchar(255) DEFAULT NULL COMMENT 'Path to widget template',
  PRIMARY KEY (`page_id`),
  KEY `WIDGET_INSTANCE_PAGE_INSTANCE_ID` (`instance_id`),
  CONSTRAINT `WIDGET_INSTANCE_PAGE_INSTANCE_ID_WIDGET_INSTANCE_INSTANCE_ID` FOREIGN KEY (`instance_id`) REFERENCES `widget_instance` (`instance_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='Instance of Widget on Page';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_instance_page`
--

LOCK TABLES `widget_instance_page` WRITE;
/*!40000 ALTER TABLE `widget_instance_page` DISABLE KEYS */;
INSERT INTO `widget_instance_page` VALUES (1,1,'pages','contact_index_index','content.top','all','','widget/static_block/default.phtml'),(2,2,'all_pages','default','cms_footer_links_container','all','','widget/static_block/default.phtml'),(3,3,'anchor_categories','catalog_category_view_type_layered','sidebar.main','specific','37','widget/static_block/default.phtml'),(4,4,'anchor_categories','catalog_category_view_type_layered','sidebar.main','specific','3','widget/static_block/default.phtml'),(5,5,'anchor_categories','catalog_category_view_type_layered','sidebar.main','specific','11','widget/static_block/default.phtml'),(6,6,'anchor_categories','catalog_category_view_type_layered','sidebar.main','specific','20','widget/static_block/default.phtml'),(7,7,'anchor_categories','catalog_category_view_type_layered','sidebar.main','specific','38','widget/static_block/default.phtml'),(8,8,'anchor_categories','catalog_category_view_type_layered','content.top','specific','20','widget/static_block/default.phtml'),(9,9,'anchor_categories','catalog_category_view_type_layered','content.top','specific','9','widget/static_block/default.phtml'),(10,10,'anchor_categories','catalog_category_view_type_layered','content.top','specific','11','widget/static_block/default.phtml'),(11,11,'anchor_categories','catalog_category_view_type_layered','content.top','specific','3','widget/static_block/default.phtml'),(12,12,'anchor_categories','catalog_category_view_type_layered','content.top','specific','38','widget/static_block/default.phtml'),(13,13,'anchor_categories','catalog_category_view_type_layered','content.top','specific','37','widget/static_block/default.phtml'),(14,14,'pages','cms_index_index','content','all','','widget/static_block/default.phtml'),(15,15,'anchor_categories','catalog_category_view_type_layered','content.top','specific','39','widget/static_block/default.phtml'),(16,16,'anchor_categories','catalog_category_view_type_layered','content.top','specific','40','widget/static_block/default.phtml'),(17,17,'pages','customer_account_login','customer.login.container','all','','widget/static_block/default.phtml'),(18,18,'anchor_categories','catalog_category_view_type_layered','content.top','specific',NULL,'widget/static_block/default.phtml');
/*!40000 ALTER TABLE `widget_instance_page` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:36:37
