CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_user_session`
--

DROP TABLE IF EXISTS `admin_user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_session` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Entity ID',
  `session_id` varchar(128) NOT NULL COMMENT 'Session ID value',
  `user_id` int(10) unsigned DEFAULT NULL COMMENT 'Admin User ID',
  `status` smallint(5) unsigned NOT NULL DEFAULT 1 COMMENT 'Current Session status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Created Time',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Update Time',
  `ip` varchar(15) NOT NULL COMMENT 'Remote user IP',
  PRIMARY KEY (`id`),
  KEY `ADMIN_USER_SESSION_SESSION_ID` (`session_id`),
  KEY `ADMIN_USER_SESSION_USER_ID` (`user_id`),
  CONSTRAINT `ADMIN_USER_SESSION_USER_ID_ADMIN_USER_USER_ID` FOREIGN KEY (`user_id`) REFERENCES `admin_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='Admin User sessions table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user_session`
--

LOCK TABLES `admin_user_session` WRITE;
/*!40000 ALTER TABLE `admin_user_session` DISABLE KEYS */;
INSERT INTO `admin_user_session` VALUES (1,'opfvcp29d82u23vo317obf0h95',1,1,'2020-09-18 22:36:24','2020-09-18 22:45:25','127.0.0.1'),(2,'p0aj8u2rchmru1ba6e16telqsl',1,1,'2020-09-19 01:43:49','2020-09-19 01:43:49','127.0.0.1'),(3,'lksvgp4nisi3sjvimt3aca18et',1,1,'2020-09-19 02:08:04','2020-09-19 02:16:52','127.0.0.1'),(4,'7k91pvd4domlt6hr39f0d737tb',1,1,'2020-09-19 02:46:33','2020-09-19 02:55:40','127.0.0.1'),(5,'rsd8r1th748rt0d79pi87vlc7t',1,1,'2020-09-19 23:15:57','2020-09-19 23:16:48','127.0.0.1'),(6,'ndp2dk3q6c93rsre71i1sqdesl',1,1,'2020-09-19 23:41:53','2020-09-19 23:48:43','127.0.0.1'),(7,'62m49798s1hhvb6i698gs9spce',1,1,'2020-09-21 22:09:30','2020-09-21 22:36:19','127.0.0.1'),(8,'76akdn46ad2l7r6r3u42pie6l8',1,1,'2020-09-21 22:53:36','2020-09-21 22:54:22','127.0.0.1'),(9,'qib3r1rvtq6rjlr4la9b5avs50',1,1,'2020-09-21 23:28:57','2020-09-21 23:43:11','127.0.0.1'),(10,'jbtrotvd6vnc9ci9jf30ij26j7',1,1,'2020-09-22 01:58:09','2020-09-22 01:58:09','127.0.0.1'),(11,'bjgjg5gcb5qkpb2c2ej97volns',1,1,'2020-09-22 17:16:56','2020-09-22 17:30:31','127.0.0.1'),(12,'nmjmj938nt5tnf27b84eqsgvho',1,1,'2020-09-23 16:10:17','2020-09-23 16:42:10','127.0.0.1'),(13,'ur9qjrmglg3vc1ap07voec6jia',1,1,'2020-09-24 01:41:12','2020-09-24 01:43:33','127.0.0.1'),(14,'dsf9pbc856t0f6kdpddj2f6f7n',1,1,'2020-09-24 02:38:06','2020-09-24 02:53:31','127.0.0.1'),(15,'dfgskpgg7921kss6idme2k0bd7',1,1,'2020-09-24 03:14:54','2020-09-24 03:15:24','127.0.0.1'),(16,'cq7c35rd3qvpkhqdngls3lrj94',1,1,'2020-09-24 03:34:45','2020-09-24 03:35:36','127.0.0.1'),(17,'4c4i1gh6ov23seg0tklp534ng7',1,1,'2020-09-24 04:19:11','2020-09-24 04:21:38','127.0.0.1'),(18,'51q3nbiap1hsgiavr0k2robqb8',1,1,'2020-09-24 22:36:33','2020-09-24 23:00:09','127.0.0.1'),(19,'ehlohones06veom3j2jkrqpbt5',1,1,'2020-09-25 00:59:57','2020-09-25 01:17:46','127.0.0.1'),(20,'niseae1cri7ksj6rqgvhviv1rd',1,1,'2020-09-25 01:53:09','2020-09-25 02:27:18','127.0.0.1'),(21,'tdrvcfdstpdssc2u15arbgdob9',1,1,'2020-09-26 19:23:49','2020-09-26 19:25:26','127.0.0.1'),(22,'1bdl7e8468fnktrgcoe4jrs4a5',1,1,'2020-09-28 03:12:28','2020-09-28 03:29:58','127.0.0.1'),(23,'mif7k0f00oesmgo776m0fdovrp',1,1,'2020-09-28 04:06:41','2020-09-28 04:15:17','127.0.0.1'),(24,'vol15cqsaimuvbtt8un8guqaag',1,1,'2020-09-28 05:01:58','2020-09-28 05:07:02','127.0.0.1'),(25,'55rd7tbm5o2m9jctb6vs2lll6d',1,1,'2020-10-14 03:23:57','2020-10-14 03:23:57','127.0.0.1'),(26,'0en7v7enh2dt56ifcc06341l9p',1,1,'2020-10-14 16:07:46','2020-10-14 16:08:42','127.0.0.1'),(27,'66tm0nm588g6u758hga7idc48s',1,1,'2020-10-14 17:13:59','2020-10-14 17:28:04','127.0.0.1'),(28,'dg8hb17oi5fcuheeahqm3d12jj',1,1,'2020-10-14 18:39:07','2020-10-14 18:52:50','127.0.0.1'),(29,'st8ibm35pbl262e276uspo8bht',1,1,'2020-10-14 19:33:11','2020-10-14 19:34:38','127.0.0.1'),(30,'1ghgcjcg61c4dbfqf4dh9g3seh',1,1,'2020-10-17 01:54:17','2020-10-17 01:55:52','127.0.0.1'),(31,'grf2sj64m5s01bmhhet923gl4u',1,1,'2020-10-21 01:52:31','2020-10-21 01:54:10','127.0.0.1');
/*!40000 ALTER TABLE `admin_user_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-21 11:37:16
