CREATE DATABASE  IF NOT EXISTS `magento_pro2` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `magento_pro2`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: magento_pro2
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `widget_instance`
--

DROP TABLE IF EXISTS `widget_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_instance` (
  `instance_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Instance ID',
  `instance_type` varchar(255) DEFAULT NULL COMMENT 'Instance Type',
  `theme_id` int(10) unsigned NOT NULL COMMENT 'Theme ID',
  `title` varchar(255) DEFAULT NULL COMMENT 'Widget Title',
  `store_ids` varchar(255) NOT NULL DEFAULT '0' COMMENT 'Store ids',
  `widget_parameters` text DEFAULT NULL COMMENT 'Widget parameters',
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Sort order',
  PRIMARY KEY (`instance_id`),
  KEY `WIDGET_INSTANCE_THEME_ID_THEME_THEME_ID` (`theme_id`),
  CONSTRAINT `WIDGET_INSTANCE_THEME_ID_THEME_THEME_ID` FOREIGN KEY (`theme_id`) REFERENCES `theme` (`theme_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='Instances of Widget for Package Theme';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_instance`
--

LOCK TABLES `widget_instance` WRITE;
/*!40000 ALTER TABLE `widget_instance` DISABLE KEYS */;
INSERT INTO `widget_instance` VALUES (1,'Magento\\Cms\\Block\\Widget\\Block',3,'Contact us info','0','{\"block_id\":\"2\"}',0),(2,'Magento\\Cms\\Block\\Widget\\Block',3,'Footer Links','0','{\"block_id\":\"1\"}',0),(3,'Magento\\Cms\\Block\\Widget\\Block',3,'Sale Left Menu','0','{\"block_id\":\"3\"}',0),(4,'Magento\\Cms\\Block\\Widget\\Block',3,'Gear Left Menu','0','{\"block_id\":\"4\"}',0),(5,'Magento\\Cms\\Block\\Widget\\Block',3,'Men\'s Left Menu','0','{\"block_id\":\"5\"}',0),(6,'Magento\\Cms\\Block\\Widget\\Block',3,'Women\'s Left Menu','0','{\"block_id\":\"6\"}',0),(7,'Magento\\Cms\\Block\\Widget\\Block',3,'What\'s New Left Menu','0','{\"block_id\":\"7\"}',0),(8,'Magento\\Cms\\Block\\Widget\\Block',3,'Women Category Content','0','{\"block_id\":\"8\"}',0),(9,'Magento\\Cms\\Block\\Widget\\Block',3,'Training Category Content','0','{\"block_id\":\"9\"}',0),(10,'Magento\\Cms\\Block\\Widget\\Block',3,'Men Category Content','0','{\"block_id\":\"10\"}',0),(11,'Magento\\Cms\\Block\\Widget\\Block',3,'Gear Category Content','0','{\"block_id\":\"11\"}',0),(12,'Magento\\Cms\\Block\\Widget\\Block',3,'New Products Category Content','0','{\"block_id\":\"13\"}',0),(13,'Magento\\Cms\\Block\\Widget\\Block',3,'Sale Category Content','0','{\"block_id\":\"12\"}',0),(14,'Magento\\Cms\\Block\\Widget\\Block',3,'Home Page','0','{\"block_id\":\"14\"}',0),(15,'Magento\\Cms\\Block\\Widget\\Block',3,'Performance Fabrics','0','{\"block_id\":\"15\"}',0),(16,'Magento\\Cms\\Block\\Widget\\Block',3,'Eco Friendly','0','{\"block_id\":\"16\"}',0),(17,'Magento\\Cms\\Block\\Widget\\Block',3,'Login Info','0','{\"block_id\":\"18\"}',0),(18,'Magento\\Cms\\Block\\Widget\\Block',3,'Giftcard Category Content','0','{\"block_id\":\"17\"}',0);
/*!40000 ALTER TABLE `widget_instance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-01 10:30:20
